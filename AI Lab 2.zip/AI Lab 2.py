# While Loop Example
# Python program to illustrate while loop

count = 0

while count < 3:
    count = count + 1
    print("Hello Geek")


# Single Statement While Block

count = 0

while count == 0:
    print("Hello Geek")
    count = count + 1


# For In Loop

# Example 1
print("List Iteration")

l = ["geeks", "for", "geeks"]

for i in l:
    print(i)


# Example 2
print("\nTuple Iteration")

t = ("geeks", "for", "geeks")

for i in t:
    print(i)


# Example 3
print("\nString Iteration")

s = "Geeks"

for i in s:
    print(i)


# Iterating by Index of Sequences

my_list = ["geeks", "for", "geeks"]

for index in range(len(my_list)):
    print(my_list[index])


# Loop Control Statements

# Continue Statement

for letter in "geeksforgeeks":
    if letter == "e" or letter == "s":
        continue
    print("Current Letter:", letter)


# Break Statement

for letter in "geeksforgeeks":
    if letter == "e" or letter == "s":
        break

print("Current Letter:", letter)


# Creating a Function

def my_function():
    print("Hello from a function")


# Calling a Function

my_function()


# Parameters

def my_function(fname):
    print(fname + " Refsnes")


my_function("Emil")
my_function("Tobias")
my_function("Linus")


# Default Parameter Value

def my_function(country="Norway"):
    print("I am from " + country)


my_function("Sweden")
my_function("India")
my_function()
my_function("Brazil")


# Passing a List as a Parameter

def my_function(food):
    for x in food:
        print(x)


fruits = ["apple", "banana", "cherry"]

my_function(fruits)


# Return Values

def my_function(x):
    return 5 * x


print(my_function(3))
print(my_function(5))
print(my_function(9))


# Keyword Arguments

def my_function(child3, child2, child1):
    print("The youngest child is " + child3)


my_function(child1="Emil", child2="Tobias", child3="Linus")


# Create a Class

class MyClass:
    x = 5


# Create Object

p1 = MyClass()

print(p1.x)


# The __init__() Function

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age


p1 = Person("John", 36)

print(p1.name)
print(p1.age)


# Object Methods

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def myfunc(self):
        print("Hello my name is " + self.name)


p1 = Person("John", 36)

p1.myfunc()
